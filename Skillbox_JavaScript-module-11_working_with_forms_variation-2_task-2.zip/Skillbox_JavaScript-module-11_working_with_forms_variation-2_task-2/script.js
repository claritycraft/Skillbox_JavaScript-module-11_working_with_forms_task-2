const inputProduct = document.querySelector('#product');
const inputWeight = document.querySelector('#weight');
const inputDistance = document.querySelector('#distance');
const buttonEl = document.querySelector('#button');
const tbodyEl = document.querySelector('#tbody');

const validateProduct = () => {
  const nameProduct = inputProduct.value.trim();

  if (nameProduct === '') {
    inputProduct.setCustomValidity('Заполните это поле');
    inputProduct.reportValidity();
    return false;
  } else {
    inputProduct.setCustomValidity('');
    return true;
  }
};

const validateWeight = () => {
  const productWeight = Number(inputWeight.value.trim());

  if (inputWeight.value.trim() === '') {
    inputWeight.setCustomValidity('Заполните это поле');
    inputWeight.reportValidity();
    return false;
  } else if (isNaN(productWeight) || productWeight < 1) {
    inputWeight.setCustomValidity('Введите корректные значения');
    inputWeight.reportValidity();
    return false;
  } else {
    inputWeight.setCustomValidity('');
    return true;
  }
};

const validateDistance = () => {
  const distance = Number(inputDistance.value.trim());

  if (inputDistance.value.trim() === '') {
    inputDistance.setCustomValidity('Заполните это поле');
    inputDistance.reportValidity();
    return false;
  } else if (distance < 1) {
    inputDistance.setCustomValidity('Введите корректные значения');
    inputDistance.reportValidity();
    return false;
  } else {
    inputDistance.setCustomValidity('');
    return true;
  }
};

const calculateDelivery = () => {};

buttonEl.addEventListener('click', function (e) {
  e.preventDefault();

  const validateProductFu = validateProduct();
  console.log(
    `я кнопка - Ты нажал на меня - я видна и вызову фолз если не заполнено поле: ${validateProductFu}`
  );
  const validateWeightFu = validateWeight();
  console.log(
    `я кнопка - Ты нажал на меня - я видна и вызову фолз если не заполнено поле: ${validateWeightFu}`
  );
  const validateDistanceFu = validateDistance();

  if (validateProductFu && validateWeightFu && validateDistanceFu) {
    const product = inputProduct.value.trim();

    const weight = inputWeight.value.trim();

    const distance = inputDistance.value.trim();

    const calculatePrice = (weight * distance) / 10;

    tbodyEl.innerHTML += `
        <tr>
            <td>${product}</td>
            <td>${weight}</td>
            <td>${distance}</td>
            <td>${calculatePrice} рублей</td>
        </tr>
 `;

    inputProduct.value = '';
    inputWeight.value = '';
    inputDistance.value = '';
  }
});
