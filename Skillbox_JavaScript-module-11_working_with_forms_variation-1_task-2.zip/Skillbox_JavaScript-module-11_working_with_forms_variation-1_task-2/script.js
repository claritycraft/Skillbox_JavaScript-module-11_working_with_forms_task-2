function addProduct(event) {
  event.preventDefault();

  const name = document.getElementById("product-name");
  const weight = document.getElementById("product-weight");
  const distance = document.getElementById("delivery-distance");
  const errorMessage = document.getElementById("error-message");

  let isValid = true;

  // Убираем красные рамки перед проверкой
  name.classList.remove("error");
  weight.classList.remove("error");
  distance.classList.remove("error");

  let weightValue = parseFloat(weight.value);
  let distanceValue = parseFloat(distance.value);

  if (isNaN(weightValue) || weightValue <= 0) {
    weight.classList.add("error");
    isValid = false;
  }

  if (isNaN(distanceValue) || distanceValue <= 0) {
    distance.classList.add("error");
    isValid = false;
  }

  // Показываем или скрываем сообщение
  if (!isValid) {
    errorMessage.style.display = "block";
    return false;
  } else {
    errorMessage.style.display = "none";
  }

  // Рассчитываем стоимость
  const cost = (weightValue * distanceValue) / 10;

  // Добавляем данные в таблицу
  document.getElementById("product-list").innerHTML += `<tr>
                    <td>${name.value.trim()}</td>
                    <td>${weight.value}</td>
                    <td>${distance.value}</td>
                    <td>${cost.toFixed(2)}</td>
                </tr>`;

  // Очищаем поля
  name.value = "";
  weight.value = "";
  distance.value = "";

  return true;
}
